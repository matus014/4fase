let receita= {

    nome:"",
    preparo:"",
    ingrediente_1:"",

}


function Cadastrar(){}

function PaginaExcluir(){}
function PaginaPesquisar(){}
function PaginaCadastro(){}


function Add(){

}